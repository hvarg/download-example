#!/usr/bin/env bash
wget https://dev.mint.isi.edu/images/QUIC-Fire.png
